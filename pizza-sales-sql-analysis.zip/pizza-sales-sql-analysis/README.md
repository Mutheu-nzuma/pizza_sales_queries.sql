# 🍕 Pizza Sales SQL Analysis

This project contains a set of SQL queries designed to analyze pizza sales data. It covers key performance indicators, trends, and insights into pizza category and size preferences.

## 📊 KPIs

1. **Total Revenue**
2. **Average Order Value**
3. **Total Pizzas Sold**
4. **Total Orders**
5. **Average Pizzas Per Order**

## 📈 Trends & Insights

- Daily and monthly order trends
- Sales % by category and size
- Top and bottom 5 pizzas by revenue, quantity, and order count

## 📁 Files

- `pizza_sales_queries.sql`: Contains all SQL queries used in the analysis

## 📌 Notes

Use filters (e.g., `WHERE pizza_category = 'Classic'`) to narrow down analysis by category or size.

---

✅ Inspired by Data Tutorials YouTube Channel
